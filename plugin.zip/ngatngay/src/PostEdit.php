<?php

class PostEdit {
    private static $prefix = 'post_';

    public static function add($key, $render, $process) {
        
        
// server
add_action('save_post', function ($postId) {
    update_post_meta($postId, 'name_diff', $_POST['meta_name_diff'] ?? '');
});

add_action('add_meta_boxes', function () {
    $nameDiff = function () {
        $postId = get_the_ID();
        $value = get_post_meta($postId, 'name_diff', true);

        echo '<input name="meta_name_diff" rows="1" style="width:100%" value="' . esc_html($value) . '">';
    };
    add_meta_box(
        'post_name_diff',
        'Tên khác',
        $nameDiff,
        'post'
    );
});

        
    }
}
