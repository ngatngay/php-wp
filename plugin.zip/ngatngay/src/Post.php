<?php

namespace NgatNgay\WordPressHelper;

class Post {
    public static function getRandom($limit = 10) {
        return get_posts([
          'posts_per_page' => $limit,
          'orderby' => 'rand'
        ]);
    }
}
