<?php

namespace NgatNgay\WordPressHelper;

class Tax
{
    public static function add($key, $title, $type = 'post', $args = [])
    {
        $args = array_merge([
            'labels' => [
                'name' => $title
            ]
        ], $args);
        register_taxonomy($key, $type, $args);
    }
}
