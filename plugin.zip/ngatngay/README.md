# Simple Helper for WordPress

work for me, use by me! :D

## Install

Download and Install.

## Requirem

for theme:
```php
if (!in_array('ngatngay/plugin.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    echo 'miss plugin';
    return;
}
```

for plugin:
```php
if (!in_array('ngatngay/plugin.php', apply_filters('active_plugins', get_option('active_plugins')))) {
	exit('miss plugin');
}
```