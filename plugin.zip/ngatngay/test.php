<?php

foreach (glob('src/*') as $file) {
	require $file;
}

