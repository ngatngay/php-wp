<?php

/*
 * Plugin Name: WordPress Helper
 * Version: 1.6
 */

defined('ABSPATH') or exit;

use NgatNgay\WordPressHelper\Updater;

require __DIR__ . '/vendor/autoload.php';

Updater::init(
    'https://cdn.ngatngay.net/wp/ngatngay/plugin.json',
    __FILE__
);
